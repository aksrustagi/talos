"""
Talos API — FastAPI server.

Run:
    uvicorn talos.api.server:app --reload --port 8000

Endpoints:
    POST /requisitions          Submit a new procurement request
    GET  /requisitions          List all requisitions
    GET  /requisitions/{id}     Get specific requisition with all agent outputs
    POST /prices/check          Check pricing for an item
    POST /savings/verify        Verify a savings claim
    POST /savings/optimize      Find optimization opportunities in spend data
    POST /knowledge             Ask a procurement question
    GET  /dashboard             Summary stats
    GET  /costs                 LLM cost breakdown
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ..config import get_config
from ..agents.pipeline import RequisitionPipelineRunner, SavingsAnalyzer
from ..agents.core import TalosAgents
from ..db import TalosDB

log = logging.getLogger("talos.api")

# ---- Globals (initialized on startup) ----
pipeline_runner: RequisitionPipelineRunner | None = None
savings_analyzer: SavingsAnalyzer | None = None
agents: TalosAgents | None = None
db: TalosDB | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global pipeline_runner, savings_analyzer, agents, db
    config = get_config()
    
    pipeline_runner = RequisitionPipelineRunner(config.client_type.value)
    savings_analyzer = SavingsAnalyzer(config.client_type.value)
    agents = TalosAgents(config.client_type.value)
    db = TalosDB(config.db_path)
    
    log.info(f"Talos API started | client={config.client_type.value} | db={config.db_path}")
    yield
    
    await pipeline_runner.close()
    await savings_analyzer.close()
    await agents.close()


app = FastAPI(
    title="Talos AI — Procurement Intelligence",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- Request/Response Models ----

class RequisitionRequest(BaseModel):
    raw_text: str
    requester_name: str = ""
    department: str = ""
    channel: str = "portal"
    auto_generate_po: bool = False

class PriceCheckRequest(BaseModel):
    item_description: str
    current_price: float | None = None
    quantity: int = 1

class SavingsVerifyRequest(BaseModel):
    description: str
    baseline_price: float
    new_price: float
    volume: int
    category: str = ""
    evidence: list[str] = []

class OptimizationRequest(BaseModel):
    spend_data: str

class KnowledgeRequest(BaseModel):
    question: str


# ---- Endpoints ----

@app.post("/requisitions")
async def submit_requisition(req: RequisitionRequest):
    """Submit a procurement request. Runs full pipeline: parse → comply → aggregate → price."""
    # Check for recent similar orders for aggregation
    recent = db.find_similar_orders(req.raw_text[:50]) if db else None
    
    result = await pipeline_runner.process(
        raw_text=req.raw_text,
        requester_name=req.requester_name,
        department=req.department,
        channel=req.channel,
        recent_orders=recent,
        auto_generate_po=req.auto_generate_po,
    )

    # Save to DB
    if db:
        db.save_pipeline(result, get_config().client_type.value)
        db.save_llm_calls(pipeline_runner.agents.router.history, result.id)

    return {
        "pipeline_id": result.id,
        "status": result.status,
        "parsed": result.parsed.model_dump() if result.parsed else None,
        "compliance": result.compliance.model_dump() if result.compliance else None,
        "aggregation": result.aggregation.model_dump() if result.aggregation else None,
        "pricing": result.pricing.model_dump() if result.pricing else None,
        "savings": result.savings.model_dump() if result.savings else None,
        "purchase_order": result.purchase_order.model_dump() if result.purchase_order else None,
        "llm_cost": result.total_llm_cost,
        "errors": result.errors,
    }


@app.get("/requisitions")
async def list_requisitions(limit: int = 50, status: str | None = None):
    """List all processed requisitions."""
    return db.list_pipelines(limit=limit, status=status)


@app.get("/requisitions/{pipeline_id}")
async def get_requisition(pipeline_id: str):
    """Get full details of a specific requisition pipeline."""
    result = db.get_pipeline(pipeline_id)
    if not result:
        raise HTTPException(404, f"Pipeline {pipeline_id} not found")
    return result.model_dump()


@app.post("/prices/check")
async def check_prices(req: PriceCheckRequest):
    """Check pricing across all sources for an item."""
    result = await agents.price_tracker(
        item_description=req.item_description,
        current_price=req.current_price,
        quantity=req.quantity,
    )
    return result.model_dump()


@app.post("/savings/verify")
async def verify_savings(req: SavingsVerifyRequest):
    """Verify a savings claim — Agent 17."""
    result = await savings_analyzer.verify_single(
        description=req.description,
        baseline_price=req.baseline_price,
        new_price=req.new_price,
        volume=req.volume,
        category=req.category,
        evidence=req.evidence,
    )
    
    if db:
        db.save_savings(result)
    
    return result.model_dump()


@app.post("/savings/optimize")
async def find_optimizations(req: OptimizationRequest):
    """Find savings opportunities in spend data — Agent 22."""
    result = await savings_analyzer.find_optimization(req.spend_data)
    return result.model_dump()


@app.get("/savings")
async def list_savings(period: str | None = None):
    """List all verified savings records."""
    return db.list_savings(period=period)


@app.get("/savings/summary")
async def savings_summary():
    """Get savings summary with Talos billing amount."""
    return db.savings_summary()


@app.post("/knowledge")
async def ask_knowledge(req: KnowledgeRequest):
    """Ask a procurement question — Knowledge Base Agent."""
    answer = await agents.knowledge_base(req.question)
    return {"question": req.question, "answer": answer}


@app.get("/dashboard")
async def dashboard():
    """Overview dashboard: pipeline counts, savings, costs, ROI."""
    return db.dashboard()


@app.get("/costs")
async def costs():
    """LLM cost breakdown by agent."""
    return db.cost_summary()


@app.get("/health")
async def health():
    config = get_config()
    return {
        "status": "healthy",
        "client": config.client_type.value,
        "api_key_set": bool(config.openrouter_api_key),
        "db": config.db_path,
        "timestamp": datetime.utcnow().isoformat(),
    }
