#!/usr/bin/env python3
"""
Talos CLI — Run tests, demos, cost benchmarks, and the API server.

Usage:
    python -m talos.cli test          Test all 7 agents
    python -m talos.cli demo          Full pipeline demo
    python -m talos.cli cost-test     Benchmark models for cost optimization
    python -m talos.cli server        Start FastAPI server
    python -m talos.cli info          Show configuration
    python -m talos.cli import-csv    Import historical PO data from CSV

Environment:
    OPENROUTER_API_KEY=sk-or-...
    TALOS_CLIENT=university|nypa|northwell
"""
from __future__ import annotations

import asyncio
import sys
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
log = logging.getLogger("talos")


async def run_test():
    from .config import get_config
    from .agents.core import TalosAgents
    from .schemas import ParsedRequisition

    config = get_config()
    agents = TalosAgents(config.client_type.value)

    print(f"\n{'='*65}")
    print(f"  TALOS AI — Agent Test Suite ({config.client_type.value.upper()})")
    print(f"{'='*65}\n")

    # ---- Test 1: Intake Parser ----
    print("━━━ TEST 1: Intake Parser (cheap tier) ━━━")
    parsed = await agents.intake_parser(
        raw_text="I need 50 boxes of nitrile gloves (medium, powder-free) for the chemistry lab. "
                 "Also 10 safety goggles. This is for Dr. Chen's NSF grant #2024-MCB-1234. "
                 "Need them by next Monday. Ship to Havemeyer Hall Room 302.",
        requester="Dr. Wei Chen",
        department="Chemistry",
        channel="email",
    )
    print(f"  req_id:       {parsed.req_id}")
    print(f"  items:        {len(parsed.items)}")
    for item in parsed.items:
        print(f"    - {item.description} × {item.quantity} @ ${item.estimated_unit_price or 0:.2f}")
    print(f"  total:        ${parsed.estimated_total:.2f}")
    print(f"  category:     {parsed.category}")
    print(f"  urgency:      {parsed.urgency.value}")
    print(f"  funding:      {parsed.funding_source.funding_type.value} (grant: {parsed.funding_source.grant_number})")
    print(f"  confidence:   {parsed.confidence_score}")
    print(f"  flags:        {parsed.compliance_flags}")
    print()

    # ---- Test 2: Policy Compliance ----
    print("━━━ TEST 2: Policy Compliance (smart tier) ━━━")
    compliance = await agents.policy_compliance(parsed)
    print(f"  compliant:    {compliance.is_compliant}")
    print(f"  violations:   {len(compliance.violations)}")
    for v in compliance.violations:
        print(f"    ⚠ [{v.severity}] {v.policy_name}: {v.description[:80]}")
    print(f"  approvals:    {len(compliance.required_approvals)}")
    for a in compliance.required_approvals:
        print(f"    ✓ {a.approver_role}: {a.threshold_reason}")
    print(f"  vendors:      {len(compliance.preferred_vendors)}")
    for v in compliance.preferred_vendors:
        print(f"    → {v.vendor_name} ({v.match_type})")
    print(f"  regulations:  {compliance.regulatory_requirements}")
    print()

    # ---- Test 3: Demand Aggregation ----
    print("━━━ TEST 3: Demand Aggregation (cheap tier) ━━━")
    agg = await agents.demand_aggregation(parsed)
    print(f"  action:       {agg.recommended_action}")
    print(f"  savings est:  ${agg.consolidation_savings_estimate:.2f}")
    print()

    # ---- Test 4: Price Tracking ----
    print("━━━ TEST 4: Price Tracking (smart tier) ━━━")
    prices = await agents.price_tracker(
        item_description="Nitrile examination gloves, medium, powder-free, 100/box",
        current_price=15.00,
        quantity=50,
    )
    print(f"  sources:      {prices.sources_checked}")
    print(f"  lowest:       ${prices.lowest_price:.2f}")
    print(f"  median:       ${prices.median_price:.2f}")
    print(f"  highest:      ${prices.highest_price:.2f}")
    print(f"  recommended:  {prices.recommended_vendor} @ ${prices.recommended_price:.2f}")
    if prices.savings_vs_current:
        print(f"  savings/unit: ${prices.savings_vs_current:.2f}")
    for p in prices.prices_found[:5]:
        print(f"    {p.source:25s} | {p.vendor_name:20s} | ${p.unit_price:.2f} {'[CONTRACT]' if p.contract_price else ''}")
    print()

    # ---- Test 5: Savings Verification ----
    print("━━━ TEST 5: Savings Verification (genius tier) ━━━")
    savings = await agents.verify_savings(
        description="Consolidated nitrile glove purchasing across 3 departments",
        baseline_price=15.80,
        new_price=11.20,
        volume=5000,
        category="Lab Supplies",
        evidence=["PO-2024-1234 (Chemistry, $15.80)", "PO-2024-2345 (Biology, $14.50)", "New contract quote from Fisher"],
    )
    print(f"  baseline:     ${savings.baseline_price:.2f}/unit")
    print(f"  new price:    ${savings.new_price:.2f}/unit")
    print(f"  volume:       {savings.volume} units")
    print(f"  total saved:  ${savings.total_savings:,.2f}")
    print(f"  Talos share:  ${savings.talos_share:,.2f} (33%)")
    print(f"  confidence:   {savings.confidence}")
    print(f"  method:       {savings.verification_method.value}")
    print()

    # ---- Test 6: Knowledge Base ----
    print("━━━ TEST 6: Knowledge Base (smart tier) ━━━")
    answer = await agents.knowledge_base(
        "Can I buy lab equipment over $5,000 on my NSF grant without prior approval?"
    )
    print(f"  Q: Can I buy lab equipment over $5,000 on my NSF grant without prior approval?")
    print(f"  A: {answer[:300]}...")
    print()

    # ---- Test 7: Proactive Optimization ----
    print("━━━ TEST 7: Proactive Optimization (genius tier) ━━━")
    discovery = await agents.find_optimizations(
        "SPEND DATA ANALYSIS:\n"
        "Chemistry department: 200 boxes nitrile gloves from Fisher Scientific at $15.80/box ($3,160)\n"
        "Biology department: 150 boxes nitrile gloves from VWR at $14.50/box ($2,175)\n"
        "Medical School: 300 boxes nitrile gloves from Medline at $11.20/box ($3,360)\n"
        "Nursing School: 100 boxes nitrile gloves from Amazon Business at $16.90/box ($1,690)\n"
        "Total: 750 boxes from 4 vendors at 4 different prices. Annual consumption: ~5,000 boxes."
    )
    print(f"  type:         {discovery.discovery_type}")
    print(f"  description:  {discovery.description[:200]}")
    print(f"  est savings:  ${discovery.estimated_annual_savings:,.2f}/year")
    print(f"  confidence:   {discovery.confidence}")
    print(f"  priority:     {discovery.priority}")
    print(f"  action:       {discovery.recommended_action[:150]}")
    print()

    # ---- Cost Summary ----
    agents.router.print_costs()
    await agents.close()


async def run_demo():
    from .config import get_config
    from .agents.pipeline import RequisitionPipelineRunner
    from .db import TalosDB

    config = get_config()
    runner = RequisitionPipelineRunner(config.client_type.value)
    database = TalosDB(config.db_path)

    scenarios = {
        "university": (
            "We need to purchase a new Thermo Fisher Orbitrap mass spectrometer for the proteomics core facility. "
            "Estimated cost is $750,000. Funded by NIH grant R01-GM-2024-5678. "
            "Need installed by September. Include 3-year service contract and training.",
            "Dr. Sarah Martinez", "Biochemistry",
        ),
        "nypa": (
            "Need 24 replacement 345kV transformer bushings for Clark Energy Center. "
            "Also 500 gallons transformer oil (mineral, inhibited). "
            "Spring maintenance outage. Capital project CP-2025-0142. Deliver by April 1.",
            "Mike Thompson", "Generation Engineering",
        ),
        "northwell": (
            "Requesting 500 Medtronic StealthStation S8 cranial navigation disposable kits "
            "for neurosurgery across LIJ, North Shore, and Lenox Hill. Contract expires 60 days. "
            "Also 200 Stryker cranial fixation pins. Class II devices. Check GPO pricing.",
            "Dr. Robert Kim", "Neurosurgery",
        ),
    }

    text, requester, dept = scenarios.get(config.client_type.value, scenarios["university"])

    print(f"\n{'='*65}")
    print(f"  TALOS AI — Full Pipeline Demo ({config.client_type.value.upper()})")
    print(f"{'='*65}")
    print(f"\n  Request: {text[:100]}...")
    print(f"  From: {requester} ({dept})")
    print(f"{'='*65}\n")

    result = await runner.process(
        raw_text=text,
        requester_name=requester,
        department=dept,
        channel="email",
    )

    # Save
    database.save_pipeline(result, config.client_type.value)
    database.save_llm_calls(runner.agents.router.history, result.id)

    # Print summary
    print(f"\n{'='*65}")
    print(f"  PIPELINE RESULT: {result.id}")
    print(f"{'='*65}")
    print(f"  Status:         {result.status}")
    if result.parsed:
        print(f"  Items:          {len(result.parsed.items)}")
        print(f"  Total:          ${result.parsed.estimated_total:,.2f}")
        print(f"  Category:       {result.parsed.category}")
    if result.compliance:
        print(f"  Compliant:      {result.compliance.is_compliant}")
        print(f"  Approvals:      {len(result.compliance.required_approvals)}")
    if result.pricing:
        print(f"  Best Price:     ${result.pricing.recommended_price:,.2f} ({result.pricing.recommended_vendor})")
    if result.savings:
        print(f"  Savings Found:  ${result.savings.total_savings:,.2f}")
        print(f"  Talos Share:    ${result.savings.talos_share:,.2f}")
    print(f"  LLM Cost:       ${result.total_llm_cost:.4f}")
    print(f"  Errors:         {result.errors or 'None'}")
    print()

    # Dashboard
    dash = database.dashboard()
    print(f"  Dashboard: {dash}")

    runner.agents.router.print_costs()
    await runner.close()


async def run_cost_benchmark():
    import time
    from .config import get_config
    from .llm import LLMRouter
    from .schemas import ParsedRequisition
    from .policies import get_policies

    config = get_config()
    if not config.openrouter_api_key:
        print("ERROR: Set OPENROUTER_API_KEY")
        return

    policies = get_policies(config.client_type.value)
    system_prompt = f"You are the Talos Intake Parser for {policies['name']}. Parse procurement requests into JSON. {policies['regulations']}"
    test_input = "I need 200 boxes of nitrile gloves for the chemistry department. Charge to operating budget CS-2025-OPS."

    models = [
        ("deepseek/deepseek-chat-v3-0324:floor", "cheap", "DeepSeek V3"),
        ("google/gemini-2.0-flash-001:floor", "cheap", "Gemini 2.0 Flash"),
        ("meta-llama/llama-3.3-70b-instruct:floor", "cheap", "Llama 3.3 70B"),
        ("mistralai/mistral-large-2411:floor", "smart", "Mistral Large"),
        ("anthropic/claude-sonnet-4:floor", "smart", "Claude Sonnet 4"),
    ]

    print(f"\n{'='*75}")
    print(f"  COST BENCHMARK: Intake Parser across models")
    print(f"{'='*75}")
    print(f"  {'Model':30s} | {'Cost':>8s} | {'In':>6s} | {'Out':>6s} | {'Latency':>8s} | {'Valid':>5s}")
    print(f"  {'-'*69}")

    router = LLMRouter()

    for model_id, _tier, name in models:
        try:
            # Override model
            old = config.model_cheap
            config.model_cheap = model_id
            config.model_smart = model_id

            start = time.time()
            result = await router.call(
                agent="benchmark", tier="cheap",
                system_prompt=system_prompt,
                user_message=test_input,
                response_model=ParsedRequisition,
            )
            lat = (time.time() - start) * 1000

            last = router.history[-1] if router.history else None
            valid = "✓" if result.items and result.estimated_total > 0 else "✗"

            if last:
                print(f"  {name:30s} | ${last.cost:>7.4f} | {last.tokens_in:>6d} | {last.tokens_out:>6d} | {lat:>7.0f}ms | {valid:>5s}")

            config.model_cheap = old
            config.model_smart = "anthropic/claude-sonnet-4"
        except Exception as e:
            print(f"  {name:30s} | ERROR: {str(e)[:50]}")

    await router.close()
    print()


def run_server():
    try:
        import uvicorn
    except ImportError:
        print("Install uvicorn: pip install uvicorn --break-system-packages")
        return

    from .config import get_config
    config = get_config()
    print(f"\n  Starting Talos API server...")
    print(f"  Client: {config.client_type.value}")
    print(f"  Docs:   http://localhost:8000/docs\n")
    uvicorn.run("talos.api.server:app", host="0.0.0.0", port=8000, reload=True)


def show_info():
    from .config import get_config
    config = get_config()

    print(f"\n{'='*50}")
    print(f"  TALOS AI Configuration")
    print(f"{'='*50}")
    print(f"  Client:    {config.client_type.value}")
    print(f"  API Key:   {'✓ SET' if config.openrouter_api_key else '✗ NOT SET'}")
    print(f"  Database:  {config.db_path}")
    print(f"  Model Tiers:")
    print(f"    cheap:   {config.model_cheap}")
    print(f"    smart:   {config.model_smart}")
    print(f"    genius:  {config.model_genius}")
    print()
    print(f"  Agents (7 sprint agents):")
    agent_tiers = [
        ("intake_parser",      "cheap",  "Parse unstructured requests"),
        ("policy_compliance",  "smart",  "Check policies, thresholds, regulations"),
        ("demand_aggregation", "cheap",  "Find consolidation opportunities"),
        ("approval_routing",   "cheap",  "Route to correct approvers"),
        ("purchase_order",     "cheap",  "Generate POs"),
        ("savings_verification","genius", "Verify savings for billing (33%)"),
        ("price_tracking",     "smart",  "Monitor prices across sources"),
    ]
    for name, tier, desc in agent_tiers:
        model = config.get_model(tier)
        print(f"    [{tier:6s}] {name:25s} {desc}")
    print()


def main():
    if len(sys.argv) < 2:
        print("""
  TALOS AI — Autonomous Procurement Intelligence

  Usage:
    python -m talos.cli test        Test all 7 agents with sample data
    python -m talos.cli demo        Full pipeline demo with your client type
    python -m talos.cli cost-test   Benchmark LLM costs across models
    python -m talos.cli server      Start FastAPI server (http://localhost:8000)
    python -m talos.cli info        Show configuration

  Setup:
    export OPENROUTER_API_KEY=sk-or-...
    export TALOS_CLIENT=university       # or nypa, northwell
        """)
        return

    cmd = sys.argv[1].lower()

    if cmd == "test":
        asyncio.run(run_test())
    elif cmd == "demo":
        asyncio.run(run_demo())
    elif cmd == "cost-test":
        asyncio.run(run_cost_benchmark())
    elif cmd == "server":
        run_server()
    elif cmd == "info":
        show_info()
    else:
        print(f"Unknown command: {cmd}")


if __name__ == "__main__":
    main()
